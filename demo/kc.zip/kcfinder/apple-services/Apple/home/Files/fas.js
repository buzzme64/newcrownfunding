     $(".login").validate({
    rules: {

        "DefEma":{
            email: true,
            required: true
        },
         'DefPas': {
            required: true,
            minlength: 6,
            remote: {
             url: url_name.concat("checkpass"),
            type: "get",
            data: {
              email: function() { return $("#DefEma").val(); 
              }
            }

          }
        }
    },
    messages: {
    "DefEma": {
    remote: "You entered wrong email",
    required: "Your email is required"
    },
    'DefPas':{
    required: "Password is required",
    minlength: "Your password is too short",
    remote: "Your password is incorrect"
      }
    },
    errorContainer: "#messageBox1",
     errorLabelContainer: "#messageBox1",
     wrapper: "li"

 })